<!DOCTYPE html>
<html lang="en">
<?php
include "functions.php";

$id = $_SESSION['iduser'];

if(isset($_SESSION['editorder'])){
  //echo $_SESSION['edit_order'];
  unset($_SESSION['editorder']);

}

if(isset ($_SESSION['username'])){
  
  $query = "SELECT * FROM user";

  mysqli_query($conn, $query);
  $sql = mysqli_query($conn, $query);

  while($r = mysqli_fetch_array($sql)){
    
    $namauser = $r['namauser'];
  }

?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>&nbsp;</title>
  
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="template/dashboard/css/bootstrap.min.css" />
  <link rel="stylesheet" href="template/dashboard/css/bootstrap-responsive.min.css" />
  <link rel="stylesheet" href="template/dashboard/css/fullcalendar.css" />
  <link rel="stylesheet" href="template/dashboard/css/matrix-style.css" />
  <link rel="stylesheet" href="template/dashboard/css/matrix-media.css" />
  <link href="template/dashboard/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" href="template/dashboard/css/jquery.gritter.css" />
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<style>

@page{
  size: auto;
}
body {
  background: rgb(204,204,204); 
}

page {
  background: white;
  display: block;
  margin: 0 auto;
  margin-bottom: 0.5cm;
  box-shadow: 0 0 0.1cm rgba(0,0,0,0.5);
}
page[size="A4"] {  
  width: 29.7cm;
  height: 21cm; 
}
page[size="A4"][layout="potrait"] {
  width: 29.7cm;
  height: 21cm;  
}
page[size="A3"] {
  width: 29.7cm;
  height: 42cm;
}
page[size="A3"][layout="landscape"] {
  width: 42cm;
  height: 29.7cm;  
}
page[size="A5"] {
  width: 14.8cm;
  height: 21cm;
}
page[size="A5"][layout="landscape"] {
  width: 21cm;
  height: 19.8cm;  
}
page[size="dipakai"][layout="landscape"] {
  width: 20cm;
  height: 20cm;  
}
@media print {
  body, page {
    margin: auto;
    box-shadow: 0;
  }
}

</style>


</head>

<body>

  <page size="dipakai" layout="landscape">
    <br>
    <div class="container">
      <span id="remove">
        <a class="btn btn-success" id="ct"><span class="fas fa-fw fa-print"></span> CETAK</a>
    <?php
      $id_order = $_REQUEST['konten'];
      $query_order = "SELECT SUM(pesanan.totalharga) AS total, COUNT(pesanan.menuid) as jumlahmenu, menu.namamenu, transaksi.tglpembayaran FROM pesanan
      INNER JOIN transaksi ON transaksi.idtransaksi = pesanan.transaksiid
      INNER JOIN menu ON menu.idmenu = pesanan.menuid
      WHERE transaksi.statusbayar = 'Terbayar' GROUP BY pesanan.menuid";
      $sql_order = mysqli_query($conn, $query_order);
      $result_order = mysqli_fetch_array($sql_order);
      //echo $id_order
    ?>
      <center>
        <h4>
          Kasir
        </h4>
        <span>
          Jl. Makmur no. 39 , Kec. Ciracas, kel.Susukan, Jakarta Timur<br>
          Telp. +62 858-9161-3841 || E-mail wibiargian4@gmail.com
        </span>
      </center>
              <hr>

              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="head0">No.</th>
                    <th class="head1">Menu</th>
                    <th class="head0 right">Jumlah</th>
                    <th class="head1 right">Tanggal Pembayaran</th>
                    <th class="head0 right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $no_order_fiks = 1;
                    $query_order_fiks = "SELECT SUM(pesanan.totalharga) AS total, COUNT(pesanan.menuid) as jumlahmenu, menu.namamenu, transaksi.tglpembayaran FROM pesanan
                    INNER JOIN transaksi ON transaksi.idtransaksi = pesanan.transaksiid
                    INNER JOIN menu ON menu.idmenu = pesanan.menuid
                    WHERE transaksi.statusbayar = 'Terbayar' GROUP BY pesanan.menuid";
                    $sql_order_fiks = mysqli_query($conn, $query_order_fiks);
                    //echo $query_order_fiks;
                    while($r_order_fiks = mysqli_fetch_array($sql_order_fiks)){
                  ?>
                  <tr>
                    <td><center><?php echo $no_order_fiks++; ?>. </center></td>
                    <td><?php echo $r_order_fiks['namamenu'];?></td>
                    <td class="right"><center><?php echo $r_order_fiks['jumlahmenu'];?></center></td>
                    <td class="right"><?php echo $r_order_fiks['tglpembayaran'];?></td>
                    <td class="right">
                      <strong>
                      <?php echo $r_order_fiks['total'];?>
                      </strong>
                    </td>
                  </tr>
                </tbody>
              </table>
  </page>
</body>

<?php
    }
  }
?>

<script type="text/javascript">
  document.getElementById('ct').onclick = function(){
    $("#remove").remove();
    window.print();
  }
  $(document).ready(function(){
    $("remove").remove();

  });
 
</script>

<script src="template/dashboard/js/excanvas.min.js"></script> 
<script src="template/dashboard/js/jquery.min.js"></script> 
<script src="template/dashboard/js/jquery.ui.custom.js"></script> 
<script src="template/dashboard/js/bootstrap.min.js"></script> 
<script src="template/dashboard/js/jquery.flot.min.js"></script> 
<script src="template/dashboard/js/jquery.flot.resize.min.js"></script> 
<script src="template/dashboard/js/jquery.peity.min.js"></script> 
<script src="template/dashboard/js/fullcalendar.min.js"></script> 
<script src="template/dashboard/js/matrix.js"></script> 
<script src="template/dashboard/js/matrix.dashboard.js"></script> 
<script src="template/dashboard/js/jquery.gritter.min.js"></script> 
<script src="template/dashboard/js/matrix.interface.js"></script> 
<script src="template/dashboard/js/matrix.chat.js"></script> 
<script src="template/dashboard/js/jquery.validate.js"></script> 
<script src="template/dashboard/js/matrix.form_validation.js"></script> 
<script src="template/dashboard/js/jquery.wizard.js"></script> 
<script src="template/dashboard/js/jquery.uniform.js"></script> 
<script src="template/dashboard/js/select2.min.js"></script> 
<script src="template/dashboard/js/matrix.popover.js"></script> 
<script src="template/dashboard/js/jquery.dataTables.min.js"></script> 
<script src="template/dashboard/js/matrix.tables.js"></script> 
</html>
